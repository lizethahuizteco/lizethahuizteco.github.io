/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package ws;

import java.sql.Connection;
import javax.jws.WebService;
import javax.jws.WebMethod;
import javax.jws.WebParam;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lizeth
 */
@WebService(serviceName = "WSOperaciones")

public class WSOperaciones {
//    private static Connection con;
//    String bd = "control";
//    String url = "jdbc:mysql://localhost:3306/control";
//    String user = "root";
//    String password = "";
//    String driver = "com.mysql.cj.jdbc.Driver";
//    private PreparedStatement PS;
//    
//    private final String SQL_Insert = "INSERT INTO registro (usuario,accion) VALUES (?,?)";
//    
//    public Connection conectar(/*String usuario, String accion*/) {
//        try {
//            Class.forName(driver);
//            con = (Connection)DriverManager.getConnection(url, user, password);
//            System.out.println("Conexion exitosa con la base de datos " + bd);
////            PS = con.prepareStatement(SQL_Insert);
////            PS.setString(1, usuario);
////            PS.setString(2, accion);
//            
////            int res = PS.executeUpdate();
////            if(res > 0){
////                System.out.println("Registro guardado");                
////            } 
//            
//        } catch (SQLException | ClassNotFoundException ex) {
//            System.err.println("Error en la conexion con la base de datos " + bd);
//            Logger.getLogger(WSOperaciones.class.getName()).log(Level.SEVERE, null, ex);
//        }finally{
////            PS=null;
//            try {
//                con.close();
//            } catch (SQLException ex) {
//                System.err.println("Error al cerrar la conexion");
//                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
//            }
//        }
//        return con;
//    }
//    
    
    
    
    
    @WebMethod(operationName = "Login")
    public boolean Login(@WebParam(name = "usuario") String usuario, @WebParam(name = "contrasena") String contrasena) {
        //TODO write your implementation code here:
        if (usuario.equals("Lola") && contrasena.equals("pass")) {            
//            conectar();
            return true;
        } else {
//            conectar();
            return false;
        }
    }

    
    @WebMethod(operationName = "procesarPago")
    public int procesarPago(@WebParam(name = "total") int total, @WebParam(name = "pago") int pago) {
        //TODO write your implementation code here:
        if (pago <= total) {
//            String pag = String.valueOf(pago);
//            conectar();
            return total - pago;
        } else {
//            String pag = String.valueOf(pago);
//            conectar();
            return -1;
        }
    }

            
    
}

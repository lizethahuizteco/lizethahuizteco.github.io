from zeep import Client

#Crear el cliente
cliente = Client('http://localhost:8080/ServicioWeb_SOAP/WSOperaciones?wsdl')

usuario = input("Nombre de usuario: ")
contrasena = input("Contrasena: ")
#Loging
if cliente.service.Login(usuario,contrasena):
    #us = "Acceso a: " + usuario
    print("Credenciales correctas")
else:
    #us = "Acceso denegado"
    print("Credenciales incorrectas")


total = int(input("Total de saldo: "))
pago = int(input("Monto a pagar: "))
#Procesar pago
if cliente.service.procesarPago(total,pago)>=0:
    #accion = "Pago exitoso"
    print("Pago realizado")
else:
    #accion = "Error en el pago"
    print("Dinero insuficiente")
    
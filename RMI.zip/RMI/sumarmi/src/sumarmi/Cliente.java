/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
//package sumarmi;
//
//import java.rmi.registry.LocateRegistry;
//import java.rmi.registry.Registry;
//
//public class Cliente {
//    public static void main(String[] args) {
//        try {
//            // Obtener una referencia al registro RMI
//            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
//
//            // Buscar el objeto remoto en el registro RMI usando su nombre lógico
//            Sumador sumador = (Sumador) registry.lookup("Sumador");
//
//            // Invocar el método remoto
//            double resultado = sumador.sumar(9, 6);
//            System.out.println("Resultado de la suma: " + resultado);
//        } catch (Exception e) {
//            System.err.println("Excepción en el cliente: " + e.toString());
//            e.printStackTrace();
//        }
//    }
//}





package sumarmi;

import javax.swing.*;
import java.awt.*;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;

public class Cliente extends JFrame {

    private Sumador sumador;
    private JTextField campoPantalla;

    public Cliente(Sumador sumador) {
        this.sumador = sumador;
        
       
        
        // Configurar la interfaz gráfica
        setTitle("Calculadora");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setSize(300, 500);
        setLayout(new BorderLayout());
        setResizable(false);

        campoPantalla = new JTextField();
        campoPantalla.setEditable(false);
        campoPantalla.setHorizontalAlignment(JTextField.RIGHT);
        campoPantalla.setFont(new Font("Arial", Font.PLAIN, 50));
//        campoPantalla.setBounds(10, 10, 200, 350);

        JPanel panelBotones = new JPanel();
        panelBotones.setLayout(new GridLayout(5, 4, 10, 10));

        String[] botones = {"7", "8", "9", "÷",
                            "4", "5", "6", "x",
                            "1", "2", "3", "-",
                            "0", "C", "=", "+","H"};

        for (String buttonText : botones) {
            JButton button = new JButton(buttonText);
            button.setFont(new Font("Arial", Font.BOLD, 33));
            button.addActionListener(new ActionListener() {
                @Override
                public void actionPerformed(ActionEvent e) {
                    onButtonClick(buttonText);
                }
            });
            panelBotones.add(button);
        }

        // Establecer colores de fondo
        campoPantalla.setBackground(new Color(210, 221, 233));
        panelBotones.setBackground(new Color(210, 221, 233));

        add(campoPantalla, BorderLayout.NORTH);
        add(panelBotones, BorderLayout.CENTER);
    
    }
    
    Conexion con = new Conexion();
    String historial = con.Consultar();
    private void onButtonClick(String buttonText) {
        if (buttonText.equals("=")) {
            calcularResultado();
            operacion = Integer.toString(numero1) + op + Integer.toString(numero2) + "=" + resultado;
            
            //Conexion a la base de datos
            Conexion conexion = new Conexion();        
            conexion.conectar(operacion);//Se envia la operacion realizada para ser almacenada en la BD                                    
        } else if (buttonText.equals("C")) {
            campoPantalla.setText("");
        }else if (buttonText.equals("H")) {
            JOptionPane.showMessageDialog(null, historial, "Operaciones realizadas", 1);
        } else {
            campoPantalla.setText(campoPantalla.getText() + buttonText);
        }
    }
    String operacion = "";
    String[] elementos;
    int numero1;
    int numero2;
    char operador;
    double resultado;
    String op;
    private void calcularResultado() {
        try {
            String expresion = campoPantalla.getText();
            // Separar la expresión en números y operadores
            elementos = expresion.split("[+\\-x÷]");
            numero1 = Integer.parseInt(elementos[0]);
            numero2 = Integer.parseInt(elementos[1]);

            // Obtener el operador
            operador = expresion.charAt(elementos[0].length());

            // Invocar el método remoto
            resultado = 0;
            switch (operador) {
                case '+':
                    resultado = sumador.sumar(numero1, numero2);
                    op="+";
                    break;
                case '-':
                    resultado = sumador.restar(numero1, numero2);
                    op="-";
                    break;
                case 'x':
                    resultado = sumador.multiplicar(numero1, numero2);
                    op="x";
                    break;
                case '÷':
                    resultado = sumador.dividir(numero1, numero2);
                    op="/";
                    break;
            }                        
            campoPantalla.setText(String.valueOf(resultado));
            
        } catch (NumberFormatException ex) {
            JOptionPane.showMessageDialog(this, "Expresion invalida", "Error", JOptionPane.ERROR_MESSAGE);
        } catch (Exception ex) {
            JOptionPane.showMessageDialog(this, "Error, el servidor esta apagado.");
        }
        
        
    }
public String getOperacion() {
        return operacion;
    }
    
    
    public static void main(String[] args) {
        
        
        try {
            // Obtener una referencia al registro RMI
            Registry registry = LocateRegistry.getRegistry("192.168.131.26", 1099);
//            Registry registry = LocateRegistry.getRegistry("localhost", 1099);
            
            // Buscar el objeto remoto en el registro RMI usando su nombre lógico
            Sumador sumador = (Sumador) registry.lookup("Sumador");

            // Crear la interfaz gráfica estilo calculadora del cliente
            Cliente clienteCalculadora = new Cliente(sumador);
            
            
            
            // Centrar la ventana en la pantalla
            Dimension screenSize = Toolkit.getDefaultToolkit().getScreenSize();
            int x = (screenSize.width - clienteCalculadora.getWidth()) / 2;
            int y = (screenSize.height - clienteCalculadora.getHeight()) / 2;
            clienteCalculadora.setLocation(x, y);

            clienteCalculadora.setVisible(true);
        } catch (Exception e) {
            System.err.println("Excepción en el cliente: " + e.toString());
            e.printStackTrace();
        }
        
        
    }
}
/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sumarmi;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;

/**
 *
 * @author Lizeth
 */
public class Conexion {

    String bd = "calculadora";
    String url = "jdbc:mysql://localhost:3306/";
    String user = "root";
    String password = "";
    String driver = "com.mysql.cj.jdbc.Driver";

    Connection cx;
    private final String SQL_Insert = "INSERT INTO historial (operacion) VALUES (?)";
    private final String SQL_Select = "SELECT * FROM historial";
//    private final String SQL_Update = "Update historial";
    private PreparedStatement PS;
    
    public Conexion() {
    }
    
    public Connection conectar(String operacion) {
        try {
            Class.forName(driver);
            cx = DriverManager.getConnection(url + bd, user, password);
            System.out.println("Conexion exitosa con la base de datos " + bd);
            PS = cx.prepareStatement(SQL_Insert);
            PS.setString(1, operacion);
            
            int res = PS.executeUpdate();
            if(res > 0){
                System.out.println("Registro guardado");                
            } 
            
        } catch (SQLException | ClassNotFoundException ex) {
            System.err.println("Error en la conexion con la base de datos " + bd);
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }finally{
            PS=null;
            try {
                cx.close();
            } catch (SQLException ex) {
                System.err.println("Error al cerrar la conexion");
                Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
            }
        }
        return cx;
    }

    public void desconectar() {
        try {
            cx.close();
            System.out.println("Conexion con la basde de datos finalizada.");
        } catch (SQLException ex) {
            Logger.getLogger(Cliente.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public String Consultar(){
    String historialReg= "";
    Statement stmt = null; //Esto sustituirá a ps
    ResultSet rs;
    try {
        cx = DriverManager.getConnection("jdbc:mysql://localhost:3306/calculadora", "root", "");
        //String sentencia = "SELECT operacion FROM historial";        
        stmt = cx.createStatement(); //Usamos create... no prepare...
        rs = stmt.executeQuery(SQL_Select);
        while (rs.next()) {
            String operacion = rs.getString(1);
            historialReg += operacion + "\n";
        }
    } catch (SQLException ex) {
        System.out.println("Error en la consulta de registros");

    } finally {
        try {
            cx.close();
        } catch (SQLException ex) {
            System.out.println("Error en la consulta de los registros.");
            Logger.getLogger(Conexion.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    return historialReg;
}
}

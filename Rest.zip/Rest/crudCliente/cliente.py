import requests

# URL base del servidor
base_url = 'http://192.168.131.26:8000/user'

# Función para obtener todos los usuarios
def get_users():
    response = requests.get(base_url)
    if response.status_code == 200:
        return response.json()
    else:
        print("Error al obtener usuarios:", response.status_code)

# Función para obtener un usuario por su ID
def get_user_by_id(user_id):
    url = f"{base_url}/{user_id}"
    response = requests.get(url)
    if response.status_code == 200:
        return response.json()
    else:
        print("Error al obtener usuario:", response.status_code)

# Función para crear un nuevo usuario
def create_user():
    firstName = input("Ingrese el primer nombre: ")
    lastName = input("Ingrese el apellido: ")
    email = input("Ingrese el correo electrónico: ")

    user_data = {
        "firstName": firstName,
        "lastName": lastName,
        "email": email
    }

    response = requests.post(base_url, json=user_data)
    if response.status_code == 200:
        return response.json()
    else:
        print("Error al crear usuario:", response.status_code)

# Función para actualizar un usuario existente
def update_user(user_id):
    user = get_user_by_id(user_id)
    if user:
        firstName = input("Ingrese el nuevo primer nombre: ")
        lastName = input("Ingrese el nuevo apellido: ")
        email = input("Ingrese el nuevo correo electrónico: ")

        user_data = {
            "firstName": firstName,
            "lastName": lastName,
            "email": email
        }

        url = f"{base_url}/{user_id}"
        response = requests.put(url, json=user_data)
        if response.status_code == 200:
            return response.json()
        else:
            print("Error al actualizar usuario:", response.status_code)
    else:
        print("El usuario no existe.")

# Función para eliminar un usuario por su ID
def delete_user(user_id):
    user = get_user_by_id(user_id)
    if user:
        url = f"{base_url}/{user_id}"
        response = requests.delete(url)
        if response.status_code == 200:
            print("Usuario eliminado exitosamente.")
        else:
            print("Error al eliminar usuario:", response.status_code)
    else:
        print("El usuario no existe.")

# Ejemplo de uso
if __name__ == "__main__":
    while True:
        print("\n--- Menú ---")
        print("1. Obtener todos los usuarios")
        print("2. Obtener un usuario por ID")
        print("3. Crear un nuevo usuario")
        print("4. Actualizar un usuario")
        print("5. Eliminar un usuario")
        print("0. Salir")

        option = input("Seleccione una opción: ")

        if option == "1":
            print("Usuarios existentes:")
            print(get_users())
        elif option == "2":
            user_id = input("Ingrese el ID del usuario: ")
            print("Usuario:")
            print(get_user_by_id(user_id))
        elif option == "3":
            created_user = create_user()
            print("Usuario creado:", created_user)
        elif option == "4":
            user_id = input("Ingrese el ID del usuario a actualizar: ")
            update_user(user_id)
        elif option == "5":
            user_id = input("Ingrese el ID del usuario a eliminar: ")
            delete_user(user_id)
        elif option == "0":
            print("Saliendo...")
            break
        else:
            print("Opción inválida. Por favor, seleccione una opción válida.")
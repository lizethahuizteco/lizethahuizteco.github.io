const apiUrl = 'http://localhost:8090/graphql'; 
//para ejecutar este codigo tienes que poner: npm start
function displayMessage(message, containerId) {
  const container = document.getElementById(containerId);
  const messageElement = document.createElement('p');
  messageElement.textContent = message;
  container.innerHTML = '';
  container.appendChild(messageElement);
}

function displayPersonList(persons) {
  const personListContainer = document.getElementById('person-list');
  personListContainer.innerHTML = '';

  persons.forEach(person => {
    const listItem = document.createElement('li');
    listItem.textContent = `ID: ${person.id}, Telefono: ${person.rut}, Nombre: ${person.nombre}`;
    personListContainer.appendChild(listItem);
  });
}

function getPersonas() {
  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      query: `
        query {
          getPersonas {
            id
            rut
            nombre
          }
        }
      `,
    }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.errors) {
      displayMessage('Error al obtener personas.', 'list-container');
    } else {
      displayPersonList(data.data.getPersonas);
    }
  })
  .catch(error => console.error('Error:', error));
}

function addPersona(event) {
  event.preventDefault();

  const nombre = document.getElementById('nombre').value;
  const rut = parseInt(document.getElementById('rut').value);

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      query: `
        mutation {
          addPersona(input: { nombre: "${nombre}", rut: ${rut} }) {
            id
            rut
            nombre
          }
        }
      `,
    }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.errors) {
      displayMessage('Error al agregar persona.', 'add-container');
    } else {
      displayMessage(`Persona agregada: ID ${data.data.addPersona.id}`, 'add-container');
    }
  })
  .catch(error => console.error('Error:', error))
  .finally(() => {
    // Después de agregar, actualiza la lista de personas
    getPersonas();
  });
}

function updPersona(event) {
  event.preventDefault();

  const updateId = document.getElementById('updateId').value;
  const updatedNombre = document.getElementById('updatedNombre').value;
  const updatedRut = parseInt(document.getElementById('updatedRut').value);

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      query: `
        mutation {
          updPersona(id: "${updateId}", input: { nombre: "${updatedNombre}", rut: ${updatedRut} }) {
            id
            rut
            nombre
          }
        }
      `,
    }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.errors) {
      displayMessage('Error al actualizar persona.', 'update-container');
    } else {
      displayMessage(`Persona actualizada: ID ${data.data.updPersona.id}`, 'update-container');
    }
  })
  .catch(error => console.error('Error:', error))
  .finally(() => {
    // Después de actualizar, actualiza la lista de personas
    getPersonas();
  });
}

function delPersona(event) {
  event.preventDefault();

  const deleteId = document.getElementById('deleteId').value;

  fetch(apiUrl, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
    },
    body: JSON.stringify({
      query: `
        mutation {
          delPersona(id: "${deleteId}") {
            message
          }
        }
      `,
    }),
  })
  .then(response => response.json())
  .then(data => {
    if (data.errors) {
      displayMessage('Error al eliminar persona.', 'delete-container');
    } else {
      displayMessage(data.data.delPersona.message, 'delete-container');
    }
  })
  .catch(error => console.error('Error:', error))
  .finally(() => {
    // Después de eliminar, actualiza la lista de personas
    getPersonas();
  });
}

// Llama a getPersonas al cargar la página para mostrar la lista inicial
getPersonas();
